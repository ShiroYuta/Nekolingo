// Configuração da conta (sincronização entre PC e celular).
// Deixe vazio para usar o app sem conta. Quando o projeto Supabase estiver pronto,
// preencha o endereço e a chave pública ("anon public") aqui.
window.NEKO_CFG = {
  url: '',
  key: ''
};
